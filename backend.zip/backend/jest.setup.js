// jest.setup.js

// Example: Setting a global variable
globalThis.TEST_ENV = 'test';

// Example: Configuring additional matchers or mock behaviors
// (e.g., you might configure global mocks here)
console.log('Jest setup complete');
