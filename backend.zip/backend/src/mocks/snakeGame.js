// __mocks__/SnakeGame.js

class SnakeGame {
    open() {
      return 'Mocked Snake Game Opened!';
    }
  }
  
  module.exports = SnakeGame;
  